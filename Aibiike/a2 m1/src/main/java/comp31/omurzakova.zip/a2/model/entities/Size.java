package comp31.a2.model.entities;

public @interface Size {

}
