package comp31.a2.model.repositories;

public class JpaRepository<T1, T2> {

}
