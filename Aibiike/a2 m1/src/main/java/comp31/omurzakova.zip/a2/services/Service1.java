package comp31.a2.services;

public class Service1 {

}
