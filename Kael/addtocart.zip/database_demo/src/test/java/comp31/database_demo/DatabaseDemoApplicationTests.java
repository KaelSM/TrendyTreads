package comp31.database_demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DatabaseDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
