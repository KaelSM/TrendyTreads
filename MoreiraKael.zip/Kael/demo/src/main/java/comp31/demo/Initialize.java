package comp31.demo;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import  comp31.demo.Repo.ChatMessageRepository;
import  comp31.demo.Repo.ChatSessionRepository;

@Component
public class Initialize implements CommandLineRunner {

    private final ChatMessageRepository chatMessageRepository;
    private final ChatSessionRepository chatSessionRepository;

    public Initialize(ChatMessageRepository chatMessageRepository, ChatSessionRepository chatSessionRepository) {
        this.chatMessageRepository = chatMessageRepository;
        this.chatSessionRepository = chatSessionRepository;
    }

    @Override
    public void run(String... args) throws Exception {
        
    }
}
