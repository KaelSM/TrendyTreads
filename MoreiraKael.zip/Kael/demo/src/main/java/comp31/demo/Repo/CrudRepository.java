package comp31.demo.Repo;

public class CrudRepository<T1, T2> {

}
