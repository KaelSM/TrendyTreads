package trendytreads.demo.Repo;

// Version: 1.0

import org.springframework.boot.autoconfigure.security.SecurityProperties.User;
import org.springframework.stereotype.Repository;

@Repository
public class UserRepo extends CrudRepository<User, Long> {
    
     // Add methods related to user interactions here
    
    public void authenticateUser() {
        // Method to authenticate user before chatbot interaction
    }

    public void processUserMessage(String message) {
        // Method to process user message through the chatbot
    }

    public void handleChatbotResponse() {
        // Method to handle response from the chatbot
    }

    // Additional methods as per the use case requirements
    
}