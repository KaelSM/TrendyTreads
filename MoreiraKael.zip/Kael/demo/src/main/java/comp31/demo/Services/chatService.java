package comp31.demo.Services;

import java.util.List;

import org.springframework.stereotype.Service;
import comp31.demo.Models.ChatMessage;
import comp31.demo.Repo.ChatMessageRepository;


@Service
public class chatService {

    private final ChatMessageRepository chatMessageRepository;

    public chatService(ChatMessageRepository chatMessageRepository) {
        this.chatMessageRepository = chatMessageRepository;
    }

    public List<chatMessage> findAllMessages() {
        return chatMessageRepository.findAll();
    }
}

