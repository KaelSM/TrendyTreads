package comp31.demo.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import comp31.demo.Services.chatService;

@Controller
public class chatController {

    private final chatService chatService;

    public chatController(chatService chatService) {
        this.chatService = chatService;
    }

    @GetMapping("/chat-messages")
    public String showChatMessages(Model model) {
        model.addAttribute("messages", chatService.findAllMessages());
        return "chatMessages";
    }
}
