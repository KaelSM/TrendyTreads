package comp31.demo.models;

import java.time.LocalDateTime;

import lombok.Data;
import lombok.NoArgsConstructor;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
@Data
@NoArgsConstructor
public class ChatMessage {
   @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    
    private String sessionId;
    
    private String userId;
    
    private String messageContent;
    
    private LocalDateTime timestamp;

    @ManyToOne
    @JoinColumn(name = "fkey_chat_session")
    private ChatSession chatSession;

    public ChatMessage(String sessionId, String userId, String messageContent, ChatSession chatSession) {
        this.sessionId = sessionId;
        this.userId = userId;
        this.messageContent = messageContent;
        this.timestamp = LocalDateTime.now();
        this.chatSession = chatSession;
    }
}

